#include "StdInc.h"
#include "DlcContentLoader.h"
#include "HookManager.h"
#include "Logger.h"
#include "SteamConfig.h"

namespace
{
    using CreateFileA_t = HANDLE(WINAPI*)(LPCSTR, DWORD, DWORD, LPSECURITY_ATTRIBUTES, DWORD, DWORD, HANDLE);
    using CreateFileW_t = HANDLE(WINAPI*)(LPCWSTR, DWORD, DWORD, LPSECURITY_ATTRIBUTES, DWORD, DWORD, HANDLE);
    using GetFileAttributesA_t = DWORD(WINAPI*)(LPCSTR);
    using GetFileAttributesW_t = DWORD(WINAPI*)(LPCWSTR);
    using FindFirstFileA_t = HANDLE(WINAPI*)(LPCSTR, LPWIN32_FIND_DATAA);
    using FindFirstFileW_t = HANDLE(WINAPI*)(LPCWSTR, LPWIN32_FIND_DATAW);

    CreateFileA_t oCreateFileA = nullptr;
    CreateFileW_t oCreateFileW = nullptr;
    GetFileAttributesA_t oGetFileAttributesA = nullptr;
    GetFileAttributesW_t oGetFileAttributesW = nullptr;
    FindFirstFileA_t oFindFirstFileA = nullptr;
    FindFirstFileW_t oFindFirstFileW = nullptr;

    thread_local bool g_InHook = false;

    std::string WideToUtf8(LPCWSTR value)
    {
        if (!value)
            return {};

        int len = WideCharToMultiByte(CP_UTF8, 0, value, -1, nullptr, 0, nullptr, nullptr);
        if (len <= 1)
            return {};

        std::string out(static_cast<size_t>(len - 1), '\0');
        WideCharToMultiByte(CP_UTF8, 0, value, -1, out.data(), len, nullptr, nullptr);
        return out;
    }

    std::wstring Utf8ToWide(const std::string& value)
    {
        if (value.empty())
            return {};

        int len = MultiByteToWideChar(CP_UTF8, 0, value.c_str(), -1, nullptr, 0);
        if (len <= 1)
            return {};

        std::wstring out(static_cast<size_t>(len - 1), L'\0');
        MultiByteToWideChar(CP_UTF8, 0, value.c_str(), -1, out.data(), len);
        return out;
    }

    std::string Lower(std::string value)
    {
        std::transform(value.begin(), value.end(), value.begin(), [](unsigned char c)
        {
            return static_cast<char>(std::tolower(c));
        });
        return value;
    }

    bool EndsWith(const std::string& value, const std::string& suffix)
    {
        return value.size() >= suffix.size() &&
            value.compare(value.size() - suffix.size(), suffix.size(), suffix) == 0;
    }

    std::string NormalizeGamePath(std::string value)
    {
        value.erase(std::remove(value.begin(), value.end(), '"'), value.end());
        std::replace(value.begin(), value.end(), '/', static_cast<char>(std::filesystem::path::preferred_separator));

        static const char* virtualPrefixes[] =
        {
            "sim:",
            "disc:",
            "rom:"
        };

        for (const char* prefix : virtualPrefixes)
        {
            const size_t prefixIndex = Lower(value).find(prefix);
            if (prefixIndex != std::string::npos)
                value.erase(prefixIndex, std::char_traits<char>::length(prefix));
        }

        while (!value.empty() && (value.front() == '\\' || value.front() == '/'))
            value.erase(value.begin());

        return value;
    }

    bool IsWildcardPath(const std::string& path)
    {
        return path.find('*') != std::string::npos || path.find('?') != std::string::npos;
    }

    bool IsBlockedSidecarFile(const std::string& path)
    {
        const std::string lower = Lower(path);
        return lower.find("checksum") != std::string::npos ||
            lower.find("launcher") != std::string::npos ||
            EndsWith(lower, ".exe") ||
            EndsWith(lower, ".bat") ||
            EndsWith(lower, ".cmd") ||
            EndsWith(lower, ".ps1");
    }

    bool IsDebugOrTuiRequest(const std::string& raw)
    {
        const std::string lower = Lower(raw);
        static const char* tokens[] =
        {
            "no_release",
            "norelease",
            "debugmenu",
            "debug_menu",
            "ccdebugmenu",
            "relivestoryepisodedebugmenu",
            "debug",
            "data\\tui",
            "data/tui",
            "\\tui\\",
            "/tui/",
            "tui"
        };

        for (const char* token : tokens)
        {
            if (lower.find(token) != std::string::npos)
                return true;
        }

        return false;
    }

    std::vector<std::filesystem::path> BuildDebugTuiRoots()
    {
        const std::filesystem::path gameFolder = SteamConfig::GetGameFolder();
        std::vector<std::filesystem::path> roots;

        roots.push_back(gameFolder / "data" / "no_release");
        roots.push_back(gameFolder / "data" / "tui");
        roots.push_back(gameFolder / "NarutoStorm4Revived" / "mods" / "no_release");
        roots.push_back(gameFolder / "NarutoStorm4Revived" / "mods" / "tui");
        roots.push_back(gameFolder / "NarutoStorm4Revived" / "mods" / "DebugMenu");
        roots.push_back(gameFolder / "NarutoStorm4Revived" / "mods" / "debug");

        return roots;
    }

    std::vector<std::filesystem::path> BuildPatchedRoots()
    {
        const std::filesystem::path gameFolder = SteamConfig::GetGameFolder();
        std::vector<std::filesystem::path> roots;

        roots.push_back(gameFolder / "patched");
        roots.push_back(gameFolder / "NarutoStorm4Revived" / "patched");

        return roots;
    }

    bool IsReadableGameContent(const std::string& path)
    {
        const std::string lower = Lower(path);
        if (IsBlockedSidecarFile(lower))
            return false;

        static const char* exts[] =
        {
            ".cpk", ".xfbin", ".gfx", ".nsh", ".nut", ".bin", ".swf", ".xml", ".tex", ".dds", ".png", ".txt", ".ini", ".json", ".csv", ".dat", ".lst", ".msg", ".lua",
            ".mp3", ".wav", ".ogg", ".flac", ".adx", ".hca", ".acb", ".awb", ".mp4", ".mkv", ".avi", ".wmv", ".webm", ".usm", ".m2v", ".bik"
        };

        for (const char* ext : exts)
        {
            if (EndsWith(lower, ext))
                return true;
        }

        return lower.find("data") != std::string::npos || lower.find("dlc") != std::string::npos;
    }

    bool ExistsPathA(const std::string& path)
    {
        if (!oGetFileAttributesA || path.empty())
            return false;

        DWORD attrs = oGetFileAttributesA(path.c_str());
        return attrs != INVALID_FILE_ATTRIBUTES;
    }

    bool ShouldHandleRequest(const std::string& raw)
    {
        if (raw.empty())
            return false;

        const std::string lower = Lower(raw);

        // Debug/no_release/TUI content must stay mounted even when the DLC toggle is off.
        // This is what lets retail NSUNS4 probe hidden DebugMenu/TUI assets through the
        // same MinHook file hooks already used by the DLC/StormEvolution loader.
        if (IsDebugOrTuiRequest(raw))
            return true;

        if (IsReadableGameContent(raw))
            return true;

        if (!SteamConfig::IsDlcUnlockEnabled())
            return false;

        static const char* requiredTokens[] =
        {
            "dlc",
            "add_contents",
            "common_add_contents",
            "content_info",
            "dlcpackdata",
            "load_contents",
            "plus_dlc",
            "st_script_dlc",
            "ep_r2b",
            "ep_gar",
            "ep_sik",
            "evolution",
            "charicon",
            "charsel",
            "duel_",
            "freebtl_",
            "gametitle",
            "gauge_",
            "net_",
            "preset",
            "stagesel",
            "vsload",
            "xcmn",
            "network",
            "networkmode_",
            "network_sys_",
            "netbattle",
            "netmatch",
            "net_event",
            "net_search",
            "net_match",
            "net_offline",
            "net_rank",
            "net_card",
            "net_cmn",
            "net_top",
            "networkevent",
            "neteventparam",
            "neteventcharaselectparam",
            "netrankparam",
            "netbattlematchingwindow",
            "netbattlesessionselect",
            "launch",
            "movie",
            "demo",
            "event",
            "sound",
            "audio",
            "voice",
            "bgm",
            "se_",
            "adx",
            "awb",
            "acb"
        };

        for (const char* token : requiredTokens)
        {
            if (lower.find(token) != std::string::npos)
                return true;
        }

        return false;
    }

    void AddUnique(std::vector<std::string>& out, const std::filesystem::path& path)
    {
        std::string value = path.string();
        if (value.empty())
            return;

        if (std::find(out.begin(), out.end(), value) == out.end())
            out.push_back(value);
    }

    std::filesystem::path MakeRelativeOverridePath(const std::string& normalized)
    {
        std::filesystem::path relative = normalized;
        if (!relative.is_absolute())
            return relative;

        std::error_code ec;
        std::filesystem::path fromGame = std::filesystem::relative(relative, SteamConfig::GetGameFolder(), ec);
        if (!ec && !fromGame.empty())
        {
            const std::string text = fromGame.string();
            if (text.rfind("..", 0) != 0)
                return fromGame;
        }

        return {};
    }

    void AddMediaReplacementVariants(std::vector<std::string>& out, const std::filesystem::path& path)
    {
        if (path.empty() || !path.has_filename())
            return;

        static const char* mediaExts[] =
        {
            ".mp4", ".mp3", ".wav", ".ogg", ".flac", ".adx", ".hca", ".acb", ".awb", ".usm", ".mkv", ".avi", ".wmv", ".webm", ".m2v", ".bik"
        };

        for (const char* ext : mediaExts)
        {
            std::filesystem::path variant = path;
            variant.replace_extension(ext);
            AddUnique(out, variant);
        }
    }

    void AddPatchedCandidates(std::vector<std::string>& out, const std::filesystem::path& relative)
    {
        if (relative.empty() || relative.is_absolute() || IsBlockedSidecarFile(relative.string()))
            return;

        for (const std::filesystem::path& root : BuildPatchedRoots())
        {
            const std::filesystem::path direct = root / relative;
            AddUnique(out, direct);
            AddMediaReplacementVariants(out, direct);

            std::filesystem::path withoutData;
            bool skippedData = false;
            for (const auto& part : relative)
            {
                if (!skippedData && Lower(part.string()) == "data")
                {
                    skippedData = true;
                    continue;
                }
                withoutData /= part;
            }

            if (skippedData && !withoutData.empty())
            {
                const std::filesystem::path stripped = root / withoutData;
                AddUnique(out, stripped);
                AddMediaReplacementVariants(out, stripped);
            }

            const std::filesystem::path byName = root / relative.filename();
            AddUnique(out, byName);
            AddMediaReplacementVariants(out, byName);
        }
    }

    std::vector<std::string> BuildCandidates(const std::string& raw)
    {
        std::vector<std::string> result;
        if (!ShouldHandleRequest(raw))
            return result;

        const std::filesystem::path gameFolder = SteamConfig::GetGameFolder();
        const std::filesystem::path dlcFolder = SteamConfig::GetDlcFolder();
        const std::string normalized = NormalizeGamePath(raw);
        const std::filesystem::path relative = normalized;
        const std::string lower = Lower(normalized);

        if (!relative.empty() && !relative.is_absolute())
        {
            // User patched loose-file layer. Mirror the CPK path under "patched" and
            // it wins before StormEvolution, DLC folders, or original game folders.
            AddPatchedCandidates(result, relative);

            // Hidden debug/TUI mount layer. These paths are searched first so files in
            // data/no_release, data/tui, NarutoStorm4Revived/mods/no_release, and
            // NarutoStorm4Revived/mods/tui can satisfy DebugMenu/TUI file probes without
            // copying them into the normal data tree.
            for (const std::filesystem::path& root : BuildDebugTuiRoots())
            {
                if (IsBlockedSidecarFile(relative.string()))
                    continue;

                AddUnique(result, root / relative);
                AddUnique(result, root / relative.filename());

                std::filesystem::path stripped;
                bool skipPrefix = false;
                int consumed = 0;
                for (const auto& part : relative)
                {
                    const std::string partLower = Lower(part.string());
                    if (!skipPrefix && partLower == "data")
                    {
                        skipPrefix = true;
                        consumed = 1;
                        continue;
                    }
                    if (skipPrefix && consumed == 1 && (partLower == "no_release" || partLower == "tui"))
                    {
                        consumed = 2;
                        continue;
                    }
                    stripped /= part;
                }

                if (consumed >= 2 && !stripped.empty())
                    AddUnique(result, root / stripped);
            }

            // StormEvolution loose-file override layer. This lets a release folder contain
            // data/evolution/*.cpk, data/ui/*.gfx, data/system/*.xfbin, etc. and have the
            // game read those files without needing them copied into the game root.
            for (const std::string folder : SteamConfig::GetEvolutionFolders())
            {
                if (!folder.empty() && !IsBlockedSidecarFile(relative.string()))
                    AddUnique(result, std::filesystem::path(folder) / relative);
            }

            AddUnique(result, gameFolder / relative);
            AddUnique(result, dlcFolder / relative);
            AddUnique(result, gameFolder / "dlc" / relative);

            if (lower.rfind("dlc", 0) == 0)
            {
                std::filesystem::path withoutDlc;
                bool skipped = false;
                for (const auto& part : relative)
                {
                    if (!skipped)
                    {
                        skipped = true;
                        continue;
                    }
                    withoutDlc /= part;
                }

                if (!withoutDlc.empty())
                    AddUnique(result, dlcFolder / withoutDlc);
            }
        }

        for (const std::string& probe : SteamConfig::GetDlcContentProbePaths())
        {
            const std::string probeNorm = NormalizeGamePath(probe);
            const std::string probeLower = Lower(probeNorm);
            if (probeLower.empty())
                continue;

            if (lower.find(probeLower) != std::string::npos || probeLower.find(lower) != std::string::npos)
            {
                AddUnique(result, gameFolder / probeNorm);
                AddUnique(result, dlcFolder / probeNorm);
                AddUnique(result, gameFolder / "dlc" / probeNorm);
            }
        }

        if (lower.find("dlcpackdata.cpk") != std::string::npos)
        {
            AddUnique(result, gameFolder / "data" / "sim" / "dlcpackdata.cpk");
            AddUnique(result, dlcFolder / "data" / "sim" / "dlcpackdata.cpk");
            AddUnique(result, dlcFolder / "dlcpackdata.cpk");
            AddUnique(result, gameFolder / "dlc" / "data" / "sim" / "dlcpackdata.cpk");
            AddUnique(result, gameFolder / "dlc" / "dlcpackdata.cpk");
        }

        if (lower.find("content_info.xfbin") != std::string::npos)
        {
            AddUnique(result, gameFolder / "data" / "system" / "content_info.xfbin");
            AddUnique(result, dlcFolder / "data" / "system" / "content_info.xfbin");
            AddUnique(result, dlcFolder / "content_info.xfbin");
        }

        if (lower.find("common_add_contents.xfbin") != std::string::npos)
        {
            AddUnique(result, gameFolder / "data" / "network" / "PLAT" / "COMMON_ADD_CONTENTS.xfbin");
            AddUnique(result, dlcFolder / "data" / "network" / "PLAT" / "COMMON_ADD_CONTENTS.xfbin");
            AddUnique(result, dlcFolder / "COMMON_ADD_CONTENTS.xfbin");
        }


        // If the game requests only a file name or a platform-specific path, also search the
        // StormEvolution folders recursively by matching the same relative suffix/file name.
        if (IsReadableGameContent(normalized))
        {
            const std::string wantedName = Lower(std::filesystem::path(normalized).filename().string());

            std::vector<std::filesystem::path> recursiveRoots;
            for (const std::filesystem::path& patchedRoot : BuildPatchedRoots())
            {
                if (!patchedRoot.empty())
                    recursiveRoots.push_back(patchedRoot);
            }
            for (const std::string folderText : SteamConfig::GetEvolutionFolders())
            {
                if (!folderText.empty())
                    recursiveRoots.push_back(folderText);
            }
            // Do NOT recursively scan data/no_release or data/tui here.
            // Those folders contain thousands of dev-only loose files that can crash retail NSUNS4
            // if globally mounted. Debug/TUI files are only used through direct path candidates above.

            for (const std::filesystem::path& folder : recursiveRoots)
            {
                std::error_code ec;
                if (!std::filesystem::exists(folder, ec) || !std::filesystem::is_directory(folder, ec))
                    continue;

                for (std::filesystem::recursive_directory_iterator it(folder, std::filesystem::directory_options::skip_permission_denied, ec), end; it != end; it.increment(ec))
                {
                    if (ec) { ec.clear(); continue; }
                    if (!it->is_regular_file(ec))
                        continue;

                    const std::string found = it->path().generic_string();
                    if (IsBlockedSidecarFile(found))
                        continue;

                    const std::string foundLower = Lower(found);
                    const std::string foundName = Lower(it->path().filename().string());
                    if ((!wantedName.empty() && foundName == wantedName) || EndsWith(foundLower, Lower(normalized)))
                        AddUnique(result, it->path());
                }
            }
        }

        return result;
    }

    std::string FindExistingCandidate(const std::string& raw)
    {
        for (const std::string& candidate : BuildCandidates(raw))
        {
            if (ExistsPathA(candidate))
                return candidate;
        }
        return {};
    }

    std::string FindPatchedOverride(const std::string& raw)
    {
        if (!ShouldHandleRequest(raw))
            return {};

        const std::string normalized = NormalizeGamePath(raw);
        const std::filesystem::path relative = MakeRelativeOverridePath(normalized);
        if (relative.empty() || relative.is_absolute() || !IsReadableGameContent(normalized))
            return {};

        std::vector<std::string> candidates;
        AddPatchedCandidates(candidates, relative);

        for (const std::string& candidate : candidates)
        {
            if (!IsBlockedSidecarFile(candidate) && ExistsPathA(candidate))
                return candidate;
        }

        return {};
    }

    std::string FindStormEvolutionOverride(const std::string& raw)
    {
        if (!ShouldHandleRequest(raw))
            return {};

        const std::string normalized = NormalizeGamePath(raw);
        if (normalized.empty() || std::filesystem::path(normalized).is_absolute() || !IsReadableGameContent(normalized))
            return {};

        const std::filesystem::path relative = normalized;

        std::vector<std::filesystem::path> roots;
        for (const std::string folder : SteamConfig::GetEvolutionFolders())
        {
            if (!folder.empty())
                roots.push_back(folder);
        }
        // Keep this override layer limited to StormEvolution. Debug/TUI direct candidates
        // are handled in BuildCandidates only when the request explicitly contains debug/no_release/tui.

        for (const std::filesystem::path& folder : roots)
        {
            const std::filesystem::path candidate = folder / relative;
            if (!IsBlockedSidecarFile(candidate.string()) && ExistsPathA(candidate.string()))
                return candidate.string();

            const std::filesystem::path byName = folder / relative.filename();
            if (!IsBlockedSidecarFile(byName.string()) && ExistsPathA(byName.string()))
                return byName.string();
        }

        return {};
    }

    HANDLE WINAPI hkCreateFileA(LPCSTR fileName, DWORD desiredAccess, DWORD shareMode, LPSECURITY_ATTRIBUTES security, DWORD creationDisposition, DWORD flags, HANDLE templateFile)
    {
        if (g_InHook || !fileName || !oCreateFileA)
            return oCreateFileA(fileName, desiredAccess, shareMode, security, creationDisposition, flags, templateFile);

        g_InHook = true;

        std::string overridePath = FindPatchedOverride(fileName);
        std::string overrideLabel = "Patched";
        if (overridePath.empty())
        {
            overridePath = FindStormEvolutionOverride(fileName);
            overrideLabel = "StormEvolution";
        }
        if (!overridePath.empty())
        {
            HANDLE overrideHandle = oCreateFileA(overridePath.c_str(), desiredAccess, shareMode, security, creationDisposition, flags, templateFile);
            if (overrideHandle != INVALID_HANDLE_VALUE)
            {
                Logger::Info(overrideLabel + std::string(" override CreateFileA: ") + fileName + " -> " + overridePath);
                g_InHook = false;
                return overrideHandle;
            }
        }

        HANDLE handle = oCreateFileA(fileName, desiredAccess, shareMode, security, creationDisposition, flags, templateFile);
        DWORD originalError = GetLastError();

        if (handle == INVALID_HANDLE_VALUE && (originalError == ERROR_FILE_NOT_FOUND || originalError == ERROR_PATH_NOT_FOUND))
        {
            const std::string redirect = FindExistingCandidate(fileName);
            if (!redirect.empty())
            {
                handle = oCreateFileA(redirect.c_str(), desiredAccess, shareMode, security, creationDisposition, flags, templateFile);
                if (handle != INVALID_HANDLE_VALUE)
                {
                    Logger::Info(std::string("DLC loader redirected CreateFileA: ") + fileName + " -> " + redirect);
                    g_InHook = false;
                    return handle;
                }
            }
        }

        SetLastError(originalError);
        g_InHook = false;
        return handle;
    }

    HANDLE WINAPI hkCreateFileW(LPCWSTR fileName, DWORD desiredAccess, DWORD shareMode, LPSECURITY_ATTRIBUTES security, DWORD creationDisposition, DWORD flags, HANDLE templateFile)
    {
        if (g_InHook || !fileName || !oCreateFileW)
            return oCreateFileW(fileName, desiredAccess, shareMode, security, creationDisposition, flags, templateFile);

        g_InHook = true;

        const std::string rawForOverride = WideToUtf8(fileName);
        std::string overridePath = FindPatchedOverride(rawForOverride);
        std::string overrideLabel = "Patched";
        if (overridePath.empty())
        {
            overridePath = FindStormEvolutionOverride(rawForOverride);
            overrideLabel = "StormEvolution";
        }
        const std::wstring overridePathW = Utf8ToWide(overridePath);
        if (!overridePathW.empty())
        {
            HANDLE overrideHandle = oCreateFileW(overridePathW.c_str(), desiredAccess, shareMode, security, creationDisposition, flags, templateFile);
            if (overrideHandle != INVALID_HANDLE_VALUE)
            {
                Logger::Info(overrideLabel + std::string(" override CreateFileW: ") + rawForOverride + " -> " + overridePath);
                g_InHook = false;
                return overrideHandle;
            }
        }

        HANDLE handle = oCreateFileW(fileName, desiredAccess, shareMode, security, creationDisposition, flags, templateFile);
        DWORD originalError = GetLastError();

        if (handle == INVALID_HANDLE_VALUE && (originalError == ERROR_FILE_NOT_FOUND || originalError == ERROR_PATH_NOT_FOUND))
        {
            const std::string raw = WideToUtf8(fileName);
            const std::string redirect = FindExistingCandidate(raw);
            const std::wstring redirectW = Utf8ToWide(redirect);
            if (!redirectW.empty())
            {
                handle = oCreateFileW(redirectW.c_str(), desiredAccess, shareMode, security, creationDisposition, flags, templateFile);
                if (handle != INVALID_HANDLE_VALUE)
                {
                    Logger::Info(std::string("DLC loader redirected CreateFileW: ") + raw + " -> " + redirect);
                    g_InHook = false;
                    return handle;
                }
            }
        }

        SetLastError(originalError);
        g_InHook = false;
        return handle;
    }

    DWORD WINAPI hkGetFileAttributesA(LPCSTR fileName)
    {
        if (g_InHook || !fileName || !oGetFileAttributesA)
            return oGetFileAttributesA(fileName);

        g_InHook = true;
        const std::string overridePath = FindPatchedOverride(fileName);
        if (!overridePath.empty())
        {
            DWORD patchedAttrs = oGetFileAttributesA(overridePath.c_str());
            if (patchedAttrs != INVALID_FILE_ATTRIBUTES)
            {
                Logger::Info(std::string("Patched override GetFileAttributesA: ") + fileName + " -> " + overridePath);
                g_InHook = false;
                return patchedAttrs;
            }
        }

        DWORD attrs = oGetFileAttributesA(fileName);
        DWORD originalError = GetLastError();

        if (attrs == INVALID_FILE_ATTRIBUTES && (originalError == ERROR_FILE_NOT_FOUND || originalError == ERROR_PATH_NOT_FOUND))
        {
            const std::string redirect = FindExistingCandidate(fileName);
            if (!redirect.empty())
            {
                attrs = oGetFileAttributesA(redirect.c_str());
                if (attrs != INVALID_FILE_ATTRIBUTES)
                {
                    Logger::Info(std::string("DLC loader redirected GetFileAttributesA: ") + fileName + " -> " + redirect);
                    g_InHook = false;
                    return attrs;
                }
            }
        }

        SetLastError(originalError);
        g_InHook = false;
        return attrs;
    }

    DWORD WINAPI hkGetFileAttributesW(LPCWSTR fileName)
    {
        if (g_InHook || !fileName || !oGetFileAttributesW)
            return oGetFileAttributesW(fileName);

        g_InHook = true;
        const std::string rawForOverride = WideToUtf8(fileName);
        const std::string overridePath = FindPatchedOverride(rawForOverride);
        const std::wstring overridePathW = Utf8ToWide(overridePath);
        if (!overridePathW.empty())
        {
            DWORD patchedAttrs = oGetFileAttributesW(overridePathW.c_str());
            if (patchedAttrs != INVALID_FILE_ATTRIBUTES)
            {
                Logger::Info(std::string("Patched override GetFileAttributesW: ") + rawForOverride + " -> " + overridePath);
                g_InHook = false;
                return patchedAttrs;
            }
        }

        DWORD attrs = oGetFileAttributesW(fileName);
        DWORD originalError = GetLastError();

        if (attrs == INVALID_FILE_ATTRIBUTES && (originalError == ERROR_FILE_NOT_FOUND || originalError == ERROR_PATH_NOT_FOUND))
        {
            const std::string raw = WideToUtf8(fileName);
            const std::string redirect = FindExistingCandidate(raw);
            const std::wstring redirectW = Utf8ToWide(redirect);
            if (!redirectW.empty())
            {
                attrs = oGetFileAttributesW(redirectW.c_str());
                if (attrs != INVALID_FILE_ATTRIBUTES)
                {
                    Logger::Info(std::string("DLC loader redirected GetFileAttributesW: ") + raw + " -> " + redirect);
                    g_InHook = false;
                    return attrs;
                }
            }
        }

        SetLastError(originalError);
        g_InHook = false;
        return attrs;
    }

    HANDLE WINAPI hkFindFirstFileA(LPCSTR fileName, LPWIN32_FIND_DATAA data)
    {
        if (g_InHook || !fileName || !oFindFirstFileA)
            return oFindFirstFileA(fileName, data);

        g_InHook = true;
        HANDLE handle = oFindFirstFileA(fileName, data);
        DWORD originalError = GetLastError();

        if (handle == INVALID_HANDLE_VALUE && IsWildcardPath(fileName))
        {
            for (const std::string& candidate : BuildCandidates(fileName))
            {
                handle = oFindFirstFileA(candidate.c_str(), data);
                if (handle != INVALID_HANDLE_VALUE)
                {
                    Logger::Info(std::string("DLC loader redirected FindFirstFileA: ") + fileName + " -> " + candidate);
                    g_InHook = false;
                    return handle;
                }
            }
        }

        SetLastError(originalError);
        g_InHook = false;
        return handle;
    }

    HANDLE WINAPI hkFindFirstFileW(LPCWSTR fileName, LPWIN32_FIND_DATAW data)
    {
        if (g_InHook || !fileName || !oFindFirstFileW)
            return oFindFirstFileW(fileName, data);

        g_InHook = true;
        HANDLE handle = oFindFirstFileW(fileName, data);
        DWORD originalError = GetLastError();

        const std::string raw = WideToUtf8(fileName);
        if (handle == INVALID_HANDLE_VALUE && IsWildcardPath(raw))
        {
            for (const std::string& candidate : BuildCandidates(raw))
            {
                const std::wstring candidateW = Utf8ToWide(candidate);
                if (candidateW.empty())
                    continue;

                handle = oFindFirstFileW(candidateW.c_str(), data);
                if (handle != INVALID_HANDLE_VALUE)
                {
                    Logger::Info(std::string("DLC loader redirected FindFirstFileW: ") + raw + " -> " + candidate);
                    g_InHook = false;
                    return handle;
                }
            }
        }

        SetLastError(originalError);
        g_InHook = false;
        return handle;
    }

    template<typename Fn>
    bool HookKernel(const char* name, void* detour, Fn* original)
    {
        HMODULE kernel = GetModuleHandleA("kernel32.dll");
        if (!kernel)
            kernel = LoadLibraryA("kernel32.dll");
        if (!kernel)
            return false;

        void* target = reinterpret_cast<void*>(GetProcAddress(kernel, name));
        if (!target)
            return false;

        if (!HookManager::Create(target, detour, reinterpret_cast<void**>(original)))
            return false;

        if (!HookManager::Enable(target))
            return false;

        Logger::Info(std::string("DLC loader hooked kernel32!") + name);
        return true;
    }
}

namespace DlcContentLoader
{
    bool Init()
    {
        bool ok = true;
        ok &= HookKernel("CreateFileA", reinterpret_cast<void*>(&hkCreateFileA), &oCreateFileA);
        ok &= HookKernel("CreateFileW", reinterpret_cast<void*>(&hkCreateFileW), &oCreateFileW);
        ok &= HookKernel("GetFileAttributesA", reinterpret_cast<void*>(&hkGetFileAttributesA), &oGetFileAttributesA);
        ok &= HookKernel("GetFileAttributesW", reinterpret_cast<void*>(&hkGetFileAttributesW), &oGetFileAttributesW);
        ok &= HookKernel("FindFirstFileA", reinterpret_cast<void*>(&hkFindFirstFileA), &oFindFirstFileA);
        ok &= HookKernel("FindFirstFileW", reinterpret_cast<void*>(&hkFindFirstFileW), &oFindFirstFileW);

        for (const std::string folderText : SteamConfig::GetEvolutionFolders())
        {
            std::error_code ec;
            const std::filesystem::path folder = folderText;
            if (!std::filesystem::exists(folder, ec) || !std::filesystem::is_directory(folder, ec))
                continue;

            int count = 0;
            for (std::filesystem::recursive_directory_iterator it(folder, std::filesystem::directory_options::skip_permission_denied, ec), end; it != end; it.increment(ec))
            {
                if (ec) { ec.clear(); continue; }
                if (!it->is_regular_file(ec))
                    continue;
                const std::string item = it->path().string();
                if (IsBlockedSidecarFile(item))
                    continue;
                ++count;
                if (count <= 30)
                    Logger::Info("StormEvolution content registered: " + item);
            }
            Logger::Info("StormEvolution folder active: " + folder.string() + " files=" + std::to_string(count));
        }

        for (const std::filesystem::path& folder : BuildPatchedRoots())
        {
            std::error_code ec;
            if (!std::filesystem::exists(folder, ec) || !std::filesystem::is_directory(folder, ec))
            {
                Logger::Info("Patched root missing: " + folder.string());
                continue;
            }

            int count = 0;
            for (std::filesystem::recursive_directory_iterator it(folder, std::filesystem::directory_options::skip_permission_denied, ec), end; it != end; it.increment(ec))
            {
                if (ec) { ec.clear(); continue; }
                if (!it->is_regular_file(ec))
                    continue;

                const std::string item = it->path().string();
                if (IsBlockedSidecarFile(item))
                    continue;

                ++count;
                if (count <= 50)
                    Logger::Info("Patched content registered: " + item);
            }

            Logger::Info("Patched root active: " + folder.string() + " files=" + std::to_string(count));
        }

        for (const std::filesystem::path& folder : BuildDebugTuiRoots())
        {
            std::error_code ec;
            if (std::filesystem::exists(folder, ec) && std::filesystem::is_directory(folder, ec))
                Logger::Info("Debug/TUI root active: " + folder.string());
            else
                Logger::Info("Debug/TUI root missing: " + folder.string());
        }

        Logger::Info(std::string("DLC/Patched/Debug/TUI content loader initialized ") + (ok ? "OK" : "WITH FAILURES"));
        return ok;
    }

    void Shutdown()
    {
        Logger::Info("DLC content loader shutdown");
    }
}
